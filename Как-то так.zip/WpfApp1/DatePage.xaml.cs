﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace WpfApp1
{
    public partial class DatePage : Page
    {
        public static readonly DependencyProperty SelectedDateProperty =
            DependencyProperty.Register("SelectedDate", typeof(DateTime), typeof(DatePage), new PropertyMetadata(DateTime.Now));

        public bool CheckBox1IsChecked { get; set; }
        public bool CheckBox2IsChecked { get; set; }
        public bool CheckBox3IsChecked { get; set; }
        public bool CheckBox4IsChecked { get; set; }

        public DateTime SelectedDate
        {
            get { return (DateTime)GetValue(SelectedDateProperty); }
            set { SetValue(SelectedDateProperty, value); }
        }

        public DatePage(DateTime selectedDate)
        {
            InitializeComponent();
            SelectedDate = selectedDate;
            DataContext = this;
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            Application.Current.MainWindow = mainWindow;
            NavigationService?.Navigate(null);
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // При выборе галочки - отобразить галочку
            CheckBox checkBox = sender as CheckBox;
            if (checkBox != null)
            {
                // Находим соответствующую галочку для изображения
                string checkBoxName = checkBox.Name;
                string imageNumber = checkBoxName.Replace("checkBox", ""); // Получаем номер изображения
                TextBlock tickTextBlock = FindName($"TickTextBlock{imageNumber}") as TextBlock;

                if (tickTextBlock != null)
                {
                    tickTextBlock.Visibility = Visibility.Visible;
                }
            }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // При снятии галочки - скрыть галочку
            CheckBox checkBox = sender as CheckBox;
            if (checkBox != null)
            {
                // Находим соответствующую галочку для изображения
                string checkBoxName = checkBox.Name;
                string imageNumber = checkBoxName.Replace("checkBox", ""); // Получаем номер изображения
                TextBlock tickTextBlock = FindName($"TickTextBlock{imageNumber}") as TextBlock;

                if (tickTextBlock != null)
                {
                    tickTextBlock.Visibility = Visibility.Collapsed;
                }
            }
        }
    }
}