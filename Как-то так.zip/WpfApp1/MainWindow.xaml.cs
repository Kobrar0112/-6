﻿// MainWindow.xaml.cs
using System;
using System.Windows;
using System.Windows.Controls;
using WpfApp1;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private DateTime currentDate = DateTime.Today;

        public MainWindow()
        {
            InitializeComponent();
            UpdateCalendar();
        }

        private void UpdateCalendar()
        {
            MonthYearDisplay.Text = currentDate.ToString("MMMM yyyy");

            DayGrid.Children.Clear();
            DateTime startOfMonth = new DateTime(currentDate.Year, currentDate.Month, 1);
            int days = DateTime.DaysInMonth(currentDate.Year, currentDate.Month);
            int dayOfWeek = (int)startOfMonth.DayOfWeek;

            for (int i = 1; i < dayOfWeek; i++)
            {
                DayGrid.Children.Add(new DayCard { DayNumber = { Text = string.Empty } });
            }

            for (int i = 1; i <= days; i++)
            {
                DayGrid.Children.Add(new DayCard { DayNumber = { Text = i.ToString() } });
            }
        }

        private void PreviousMonth_Click(object sender, RoutedEventArgs e)
        {
            currentDate = currentDate.AddMonths(-1);
            UpdateCalendar();
        }

        private void NextMonth_Click(object sender, RoutedEventArgs e)
        {
            currentDate = currentDate.AddMonths(1);
            UpdateCalendar();
        }
    }
}