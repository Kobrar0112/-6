﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp1
{
    public partial class DayCard : UserControl
    {
        public DayCard()
        {
            InitializeComponent();
        }

        private void DayCard_MouseUp(object sender, MouseButtonEventArgs e)
        {
      
            Window parentWindow = Window.GetWindow(this);

            ContextMenu contextMenu = new ContextMenu();

            MenuItem menuItem1 = new MenuItem();
            menuItem1.Header = "Кнопка 1";
            menuItem1.Click += MenuItem_Click;

            MenuItem menuItem2 = new MenuItem();
            menuItem2.Header = "Кнопка 2";
            menuItem2.Click += MenuItem_Click;

            contextMenu.Items.Add(menuItem1);
            contextMenu.Items.Add(menuItem2);

            contextMenu.PlacementTarget = this;
            contextMenu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;

            contextMenu.IsOpen = true;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItem = (MenuItem)sender;
            string option = menuItem.Header.ToString();
            MessageBox.Show($"You clicked {option}");
        }

        private void DayNumber_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            DateTime selectedDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, int.Parse(DayNumber.Text));
            DatePage datePage = new DatePage(selectedDate);
            Window parentWindow = Window.GetWindow(this);
            parentWindow.Content = datePage;
        }
    }
}